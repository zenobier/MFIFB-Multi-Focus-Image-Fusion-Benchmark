% evaluate_images.m
% 脚本用于对多种融合方法的图像应用多个评价指标，并输出结果表格

% 清空工作区
clear; clc; close all;

% 设置图像文件夹路径
folderPath = 'Lytro'; % 原始图像文件夹路径
methods = {'CurveletResult', 'GradientResult', 'IDWTResult', 'LaplacianPyramidResult', 'MaxResult', 'nsctResult'}; % 融合方法结果文件夹

% 设置图像扩展名
imageExt = '.jpg'; % 根据实际情况调整，如 '.jpg' 或其他

% 初始化结果存储
numGroups = 40; % 总共有40组图像
variableNames = {'GroupName', 'AG', 'CC', 'SD', 'PSNR', 'MSE', 'Hab', 'QP', 'QCB', 'QG', 'VIFp'};
variableTypes = {'string', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double'};

% 定义梯度滤波器（例如 Sobel 滤波器）用于 QG 计算
flt1 = fspecial('sobel');  % 水平梯度滤波器
flt2 = flt1';               % 垂直梯度滤波器

% 处理每种方法
for methodIdx = 1:length(methods)
    methodFolder = methods{methodIdx};
    results = table('Size', [numGroups, 11], 'VariableTypes', variableTypes, 'VariableNames', variableNames);
    
    % 处理每一组图像
    for i = 1:numGroups
        % 构建当前组的图像文件名，确保组号为两位数
        groupNumber = sprintf('%02d', i);
        fileF = fullfile(methodFolder, sprintf('lytro-%s%s', groupNumber, imageExt));
        fileA = fullfile(folderPath, sprintf('lytro-%s-A%s', groupNumber, imageExt));
        fileB = fullfile(folderPath, sprintf('lytro-%s-B%s', groupNumber, imageExt));
        
        % 检查文件是否存在
        if ~isfile(fileA) || ~isfile(fileB) || ~isfile(fileF)
            warning('缺少第 %d 组的图像: %s, %s, %s', i, fileA, fileB, fileF);
            % 存储 NaN 值以表示缺失
            results(i, :) = {sprintf('lytro-%s', groupNumber), NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN};
            continue;
        end
        
        % 读取图像
        A = imread(fileA);
        B = imread(fileB);
        F = imread(fileF);
        
        % 如果图像是RGB，转换为灰度
        if size(A, 3) == 3
            A = rgb2gray(A);
        end
        if size(B, 3) == 3
            B = rgb2gray(B);
        end
        if size(F, 3) == 3
            F = rgb2gray(F);
        end
        
        % 将图像转换为双精度类型
        A = double(A);
        B = double(B);
        F = double(F);
        
        % 应用评价指标
        try
            % 假设您已有这些函数并正确定义
            AG = AG_evaluation(F);
            CC = CC_evaluation(A, B, F);
            SD = SD_evaluation(F);
            PSNR_val = PSNR_evaluation(A, B, F);
            MSE_val = MSE_evaluation(A, B, F);
            HabR = Hab(A, B, 256); % 假设灰度级为256
            QP_val = computeQP(F);
            QCB_val = computeQCB(F, {A, B});
            
            % 计算 QG
            QG_val = computeQG(A, B, F, flt1, flt2);
            
            % 计算 VIFp
            VIFp_A = computeVIFp(A, F);
            VIFp_B = computeVIFp(B, F);
            VIFp_val = (VIFp_A + VIFp_B) / 2;
            
        catch ME
            warning('在处理第 %d 组图像时发生错误: %s', i, ME.message);
            AG = NaN; CC = NaN; SD = NaN; PSNR_val = NaN; MSE_val = NaN;
            HabR = NaN; QP_val = NaN; QCB_val = NaN; QG_val = NaN; VIFp_val = NaN;
        end
        
        % 存储结果
        results(i, :) = {sprintf('lytro-%s', groupNumber), AG, CC, SD, PSNR_val, MSE_val, HabR, QP_val, QCB_val, QG_val, VIFp_val};
        
        fprintf('已处理第 %d 组图像: lytro-%s\n', i, groupNumber);
    end
    
    % 将结果保存为CSV文件
    outputCSV = sprintf('%s_evaluation_results.csv', methodFolder);
    writetable(results, outputCSV);
    fprintf('评价结果已保存到 %s\n', outputCSV);
end
