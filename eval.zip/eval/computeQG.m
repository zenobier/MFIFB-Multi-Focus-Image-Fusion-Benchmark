function res = computeQG(img1, img2, fuse, flt1, flt2)
    % computeQG Computes the QG evaluation metric for image fusion.
    %
    % Syntax:
    %   res = computeQG(img1, img2, fuse, flt1, flt2)
    %
    % Inputs:
    %   img1 - First input grayscale image.
    %   img2 - Second input grayscale image.
    %   fuse - Fused grayscale image.
    %   flt1 - Filter for the X-gradient (e.g., Sobel filter).
    %   flt2 - Filter for the Y-gradient (e.g., Sobel filter).
    %
    % Outputs:
    %   res  - Scalar value representing the QG evaluation metric.
    %
    % [后续代码...]

    %% 1) Compute Gradient Maps

    % Gradient for fused image
    fuseX = filter2(flt1, fuse, 'same'); 
    fuseY = filter2(flt2, fuse, 'same');
    fuseG = sqrt(fuseX.^2 + fuseY.^2);
    
    % Avoid division by zero for fused X-gradient
    buffer = (fuseX == 0);
    fuseX = fuseX + buffer * 1e-5;
    fuseA = atan(fuseY ./ fuseX);
    
    % Gradient for img1
    img1X = filter2(flt1, img1, 'same');
    img1Y = filter2(flt2, img1, 'same');
    img1G = sqrt(img1X.^2 + img1Y.^2); 
    
    % Avoid division by zero for img1 X-gradient
    buffer = (img1X == 0);
    img1X = img1X + buffer * 1e-5;
    img1A = atan(img1Y ./ img1X);
    
    % Gradient for img2
    img2X = filter2(flt1, img2, 'same');
    img2Y = filter2(flt2, img2, 'same'); 
    img2G = sqrt(img2X.^2 + img2Y.^2);
    
    % Avoid division by zero for img2 X-gradient
    buffer = (img2X == 0);
    img2X = img2X + buffer * 1e-5;
    img2A = atan(img2Y ./ img2X);
    
    %% 2) Edge Preservation Estimation

    % For img1
    bimap1 = img1G > fuseG;
    
    % Avoid division by zero for img1G and fuseG
    buffer = (img1G == 0);
    img1G = img1G + buffer * 1e-5;
    buffer1 = fuseG ./ img1G;
    
    buffer = (fuseG == 0);
    fuseG = fuseG + buffer * 1e-5;
    buffer2 = img1G ./ fuseG;
    
    Gaf = bimap1 .* buffer1 + (~bimap1) .* buffer2;
    Aaf = 1 - abs(img1A - fuseA) * 2 / pi; % Modified according to Eq. (4)
    
    % For img2
    bimap2 = img2G > fuseG;
    
    % Avoid division by zero for img2G and fuseG
    buffer = (img2G == 0);
    img2G = img2G + buffer * 1e-5;
    buffer1 = fuseG ./ img2G;
    
    buffer = (fuseG == 0);
    fuseG = fuseG + buffer * 1e-5;
    buffer2 = img2G ./ fuseG;
    
    Gbf = bimap2 .* buffer1 + (~bimap2) .* buffer2; 
    Abf = 1 - abs(img2A - fuseA) * 2 / pi; % Modified according to Eq. (4)
    
    %% Parameters (Can be adjusted as needed)
    gama1 = 0.9994; 
    gama2 = 0.9879; % Modified according to Fig. 1
    k1 = -15; 
    k2 = -22; 
    delta1 = 0.5; 
    delta2 = 0.8;
    
    %% Compute Qaf and Qbf
    Qg_AF = gama1 ./ (1 + exp(k1 * (Gaf - delta1)));
    Qalpha_AF = gama2 ./ (1 + exp(k2 * (Aaf - delta2))); 
    Qaf = Qg_AF .* Qalpha_AF;
    
    Qg_BF = gama1 ./ (1 + exp(k1 * (Gbf - delta1))); 
    Qalpha_BF = gama2 ./ (1 + exp(k2 * (Abf - delta2)));
    Qbf = Qg_BF .* Qalpha_BF;
    
    %% 3) Compute the Weighting Matrix 
    L = 1; % Power parameter
    
    Wa = img1G.^L;
    Wb = img2G.^L;
    
    %% Compute the Final QG Metric
    res = sum(Qaf(:) .* Wa(:) + Qbf(:) .* Wb(:)) / sum(Wa(:) + Wb(:)); 
    % Alternative implementations (commented out):
    % res = mean2(Qaf .* Wa + Qbf .* Wb) / mean2(Wa + Wb); % Equivalent to the above line
    % res = mean2( (Qaf .* Wa + Qbf .* Wb) ./ (Wa + Wb) ); % Not Equivalent to the above line
end
