function QCB = computeQCB(fusedImage, sourceImages, windowSize)
    % Handle default window size
    if nargin < 3
        windowSize = 7; % Default window size
    end

    % Validate windowSize
    if ~isscalar(windowSize) || windowSize <= 0 || mod(windowSize,2) == 0
        error('windowSize must be a positive odd integer.');
    end

    % Check if sourceImages is a cell array
    if ~iscell(sourceImages)
        error('sourceImages must be a cell array of images.');
    end

    % Number of source images
    numSources = length(sourceImages);

    % Convert fused image to grayscale if it is RGB
    if ndims(fusedImage) == 3
        fusedGray = rgb2gray(fusedImage);
    else
        fusedGray = fusedImage;
    end

    % Convert fused image to double precision
    fusedGray = double(fusedGray);

    % Compute local contrast for fused image
    fusedContrast = computeLocalContrast(fusedGray, windowSize);

    % Initialize similarity accumulator
    similaritySum = 0;

    for i = 1:numSources
        source = sourceImages{i};
        
        % Convert source image to grayscale if it is RGB
        if ndims(source) == 3
            sourceGray = rgb2gray(source);
        else
            sourceGray = source;
        end
        
        % Convert source image to double precision
        sourceGray = double(sourceGray);
        
        % Compute local contrast for source image
        sourceContrast = computeLocalContrast(sourceGray, windowSize);
        
        % Compute Structural Similarity Index (SSIM) between fused and source contrast maps
        % SSIM expects images in the range [0, 1], so normalize contrast maps
        fusedContrastNorm = mat2gray(fusedContrast);
        sourceContrastNorm = mat2gray(sourceContrast);
        
        ssimVal = ssim(fusedContrastNorm, sourceContrastNorm);
        
        similaritySum = similaritySum + ssimVal;
    end

    % Compute average similarity as QCB
    QCB = similaritySum / numSources;
end

function localContrast = computeLocalContrast(image, windowSize)
    % Define the neighborhood for standard deviation
    neighborhood = true(windowSize, windowSize);

    % Create a Gaussian filter to weight the neighborhood
    gaussianFilter = fspecial('gaussian', windowSize, windowSize/6);

    % Compute local mean
    localMean = imfilter(image, gaussianFilter, 'replicate');

    % Compute local squared mean
    localMeanSq = imfilter(image.^2, gaussianFilter, 'replicate');

    % Compute local variance
    localVariance = localMeanSq - localMean.^2;

    % Ensure variance is non-negative
    localVariance(localVariance < 0) = 0;

    % Compute local standard deviation (contrast)
    localContrast = sqrt(localVariance);
end
