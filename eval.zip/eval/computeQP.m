function QP = computeQP(fusedImage, showPhaseCongruency, phaseCongruencyParams)
% computeQP Calculates the QP evaluation metric for a fused image
%
%   QP = computeQP(fusedImage)
%   QP = computeQP(fusedImage, showPhaseCongruency)
%   QP = computeQP(fusedImage, showPhaseCongruency, phaseCongruencyParams)
%
% Input Arguments:
%   fusedImage            - The fused image, either RGB or grayscale
%   showPhaseCongruency   - (Optional) Boolean flag to display the phase congruency map, default is false
%   phaseCongruencyParams - (Optional) Structure containing parameters for the phasecong function
%
% Output:
%   QP - The QP evaluation metric, where higher values indicate better fusion quality

    % Handle default parameters
    if nargin < 2
        showPhaseCongruency = false;
    end
    if nargin < 3
        phaseCongruencyParams = struct();
    end

    % Check if the input image is empty
    if isempty(fusedImage)
        error('Input fused image is empty.');
    end

    % If the input is a file path, read the image
    if ischar(fusedImage) || isstring(fusedImage)
        if exist(fusedImage, 'file')
            fusedImage = imread(fusedImage);
        else
            error('Specified image file does not exist: %s', fusedImage);
        end
    end

    % Convert to grayscale if the image is RGB
    if size(fusedImage, 3) == 3
        fusedImage = rgb2gray(fusedImage);
    end

    % Convert image to double precision
    fusedImage = double(fusedImage);

    % Set default parameters for phase congruency if not provided
    defaultParams = struct(...
        'MinWaveLength', 3, ...
        'NumberOfScales', 4, ...
        'NumberOfOrientations', 6, ...
        'MinFeatureSize', 7, ...
        'MaxFeatureSize', 7, ...
        'NoiseThreshold', 0.85, ...
        'NormaliseAcrossScale', 0, ...
        'NormaliseAcrossOrientation', 0);

    % Merge user-provided parameters with default parameters
    paramNames = fieldnames(defaultParams);
    for i = 1:length(paramNames)
        if ~isfield(phaseCongruencyParams, paramNames{i})
            phaseCongruencyParams.(paramNames{i}) = defaultParams.(paramNames{i});
        end
    end

    % Compute the phase congruency map using the phasecong function
    [phaseCongruency, ~] = phasecong(fusedImage, ...
        phaseCongruencyParams.MinWaveLength, ...
        phaseCongruencyParams.NumberOfScales, ...
        phaseCongruencyParams.NumberOfOrientations, ...
        phaseCongruencyParams.MinFeatureSize, ...
        phaseCongruencyParams.MaxFeatureSize, ...
        phaseCongruencyParams.NoiseThreshold, ...
        phaseCongruencyParams.NormaliseAcrossScale, ...
        phaseCongruencyParams.NormaliseAcrossOrientation);

    % Optionally display the phase congruency map
    if showPhaseCongruency
        figure;
        imshow(phaseCongruency, []);
        title('Phase Congruency Map');
    end

    % Calculate the QP value as the mean of the phase congruency map
    QP = mean(phaseCongruency(:));

end
