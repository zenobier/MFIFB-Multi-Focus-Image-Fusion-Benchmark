function fused = gradientBasedFusion(img1, img2)
    % 计算图像梯度
    [Gx1, Gy1] = imgradientxy(img1);
    [Gx2, Gy2] = imgradientxy(img2);
    
    % 计算梯度幅值
    gradMag1 = sqrt(Gx1.^2 + Gy1.^2);
    gradMag2 = sqrt(Gx2.^2 + Gy2.^2);
    
    % 使用梯度幅值选择像素
    mask = gradMag1 > gradMag2;
    fused = img1 .* uint8(mask) + img2 .* uint8(~mask);
end