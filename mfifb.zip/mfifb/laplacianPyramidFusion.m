function fused = laplacianPyramidFusion(img1, img2)
    % 计算拉普拉斯金字塔
    pyr1 = laplacianPyramid(img1);
    pyr2 = laplacianPyramid(img2);
    
    % 初始化融合金字塔
    fusedPyr = cell(size(pyr1));
    
    % 融合每一层
    for level = 1:length(pyr1)
        % 使用绝对值最大选择规则
        mask = abs(pyr1{level}) > abs(pyr2{level});
        fusedPyr{level} = pyr1{level} .* uint8(mask) + pyr2{level} .* uint8(~mask);
    end
    
    % 重构融合图像
    fused = reconstructFromPyramid(fusedPyr);
end