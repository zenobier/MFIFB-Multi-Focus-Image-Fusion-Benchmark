function pyr = laplacianPyramid(img)
    % 初始化高斯和拉普拉斯金字塔
    numLevels = 5;
    gaussianPyr = cell(numLevels, 1);
    laplacianPyr = cell(numLevels, 1);
    
    % 计算高斯金字塔
    gaussianPyr{1} = img;
    for level = 2:numLevels
        gaussianPyr{level} = impyramid(gaussianPyr{level-1}, 'reduce');
    end
    
    % 计算拉普拉斯金字塔
    for level = 1:numLevels-1
        expanded = impyramid(gaussianPyr{level+1}, 'expand');
        expanded = imresize(expanded, size(gaussianPyr{level}));
        laplacianPyr{level} = gaussianPyr{level} - expanded;
    end
    laplacianPyr{numLevels} = gaussianPyr{numLevels};
    
    pyr = laplacianPyr;
end