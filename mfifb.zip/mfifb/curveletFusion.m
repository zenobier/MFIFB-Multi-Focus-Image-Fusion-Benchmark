function fused = curveletFusion(img1, img2)
    % Curvelet 变换参数
    options = struct('nbscales', 4, 'nbangles_coarse', 16, 'allcurvelets', 0);
    
    % 计算 Curvelet 变换
    C1 = fdct_wrapping(img1, 0, 2, 4, 16);
    C2 = fdct_wrapping(img2, 0, 2, 4, 16);
    
    % 初始化融合后的 Curvelet 系数
    fusedC = C1;
    
    % 融合每一层
    for s = 1:length(C1)
        for w = 1:length(C1{s})
            % 绝对值最大选择规则
            mask = abs(C1{s}{w}) > abs(C2{s}{w});
            fusedC{s}{w} = C1{s}{w} .* mask + C2{s}{w} .* ~mask;
        end
    end
    
    % 逆 Curvelet 变换重构图像
    fused = ifdct_wrapping(fusedC, 0);
end