% 需要安装 NSCT 工具箱
addpath('nsct_toolbox'); % 替换为 NSCT 工具箱的实际路径

% 设置文件夹路径
inputFolder = 'Lytro';
outputFolder = 'nsctResult';

% 设置图像编号范围
imageIndices = 1:40;

% 遍历每一对图像
for i = imageIndices
    % 生成文件名
    indexStr = sprintf('%02d', i);
    imgAPath = fullfile(inputFolder, ['lytro-', indexStr, '-A.jpg']);
    imgBPath = fullfile(inputFolder, ['lytro-', indexStr, '-B.jpg']);
    
    % 读取图像
    imgA = im2double(imread(imgAPath));
    imgB = im2double(imread(imgBPath));
    
    % 初始化融合后的图像
    fusedImage = zeros(size(imgA));
    
    % 对每个颜色通道进行融合
    for channel = 1:3
        fusedImage(:,:,channel) = nsctFusion(imgA(:,:,channel), imgB(:,:,channel));
    end
    
    % 保存融合后的图像
    outputFilePath = fullfile(outputFolder, ['lytro-', indexStr, '.jpg']);
    imwrite(fusedImage, outputFilePath);
end

function fused = nsctFusion(img1, img2)
    % NSCT 参数设置
    pfilt = 'maxflat';      % Pyramidal filter
    dfilt = 'dmaxflat7';    % Directional filter
    nlevels = [0, 1, 1, 1]; % 分解层数
    
    % 进行 NSCT 分解
    coeffs1 = nsctdec(img1, nlevels, dfilt, pfilt);
    coeffs2 = nsctdec(img2, nlevels, dfilt, pfilt);
    
    % 初始化融合系数
    fusedCoeffs = coeffs1;
    
    % 融合低频子带
    fusedCoeffs{1} = (coeffs1{1} + coeffs2{1}) / 2;
    
    % 融合高频子带
    for i = 3:length(coeffs1)
        for j = 1:length(coeffs1{i})
            % 使用绝对值最大选择规则
            mask = abs(coeffs1{i}{j}) > abs(coeffs2{i}{j});
            fusedCoeffs{i}{j} = coeffs1{i}{j} .* mask + coeffs2{i}{j} .* ~mask;
        end
    end
    
    % 重构融合图像
    fused = nsctrec(fusedCoeffs, dfilt, pfilt);
end