% 设置文件夹路径
inputFolder = 'Lytro';
outputFolder = 'IDWTResult';
imageIndices = 1:40;

% 遍历每一对图像
for i = imageIndices
    indexStr = sprintf('%02d', i);
    imgAPath = fullfile(inputFolder, ['lytro-', indexStr, '-A.jpg']);
    imgBPath = fullfile(inputFolder, ['lytro-', indexStr, '-B.jpg']);
    
    % 读取图像
    imgA = imread(imgAPath);
    imgB = imread(imgBPath);
    
    % 初始化融合后的图像
    fusedImage = zeros(size(imgA), 'like', imgA);
    
    % 对每个颜色通道进行融合
    for channel = 1:3
        % 提取单个通道
        channelA = imgA(:,:,channel);
        channelB = imgB(:,:,channel);
        
        % 小波分解
        [cA1, cH1, cV1, cD1] = dwt2(channelA, 'db1');
        [cA2, cH2, cV2, cD2] = dwt2(channelB, 'db1');
        
        % 子带融合规则：选择绝对值更大的系数
        cA = max(cA1, cA2);
        cH = max(cH1, cH2);
        cV = max(cV1, cV2);
        cD = max(cD1, cD2);
        
        % 小波重构
        fusedChannel = idwt2(cA, cH, cV, cD, 'db1');
        
        % 确保大小一致
        fusedChannel = imresize(fusedChannel, size(channelA));
        
        % 存储融合结果
        fusedImage(:,:,channel) = fusedChannel;
    end
    
    % 保存融合后的图像
    outputFilePath = fullfile(outputFolder, ['lytro-', indexStr, '.jpg']);
    imwrite(uint8(fusedImage), outputFilePath);
end