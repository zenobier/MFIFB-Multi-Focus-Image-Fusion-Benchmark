% 设置文件夹路径
inputFolder = 'Lytro';
outputFolder = 'MaxResult';

% 设置图像编号范围
imageIndices = 1:40;

% 遍历每一对图像
for i = imageIndices
    % 生成文件名
    indexStr = sprintf('%02d', i);
    imgAPath = fullfile(inputFolder, ['lytro-', indexStr, '-A.jpg']);
    imgBPath = fullfile(inputFolder, ['lytro-', indexStr, '-B.jpg']);
    
    % 读取图像
    imgA = imread(imgAPath);
    imgB = imread(imgBPath);
    
    % 初始化融合后的图像
    fusedImage = zeros(size(imgA), 'like', imgA);
    
    % 对每个颜色通道进行融合
    for channel = 1:3
        % 融合规则：选择每个像素中亮度更高的那个
        fusedImage(:,:,channel) = max(imgA(:,:,channel), imgB(:,:,channel));
    end
    
    % 保存融合后的图像
    outputFilePath = fullfile(outputFolder, ['lytro-', indexStr, '.jpg']);
    imwrite(fusedImage, outputFilePath);
end