function fused = nsctFusion(img1, img2)
    % NSCT 参数设置
    pfilt = 'maxflat';      % Pyramidal filter
    dfilt = 'dmaxflat7';    % Directional filter
    nlevels = [0, 1, 1, 1]; % 分解层数
    
    % 进行 NSCT 分解
    coeffs1 = nsctdec(img1, nlevels, dfilt, pfilt);
    coeffs2 = nsctdec(img2, nlevels, dfilt, pfilt);
    
    % 初始化融合系数
    fusedCoeffs = coeffs1;
    
    % 融合低频子带
    fusedCoeffs{1} = (coeffs1{1} + coeffs2{1}) / 2;
    
    % 融合高频子带
    for i = 2:length(coeffs1)
        for j = 1:length(coeffs1{i})
            % 使用绝对值最大选择规则
            mask = abs(coeffs1{i}{j}) > abs(coeffs2{i}{j});
            fusedCoeffs{i}{j} = coeffs1{i}{j} .* mask + coeffs2{i}{j} .* ~mask;
        end
    end
    
    % 重构融合图像
    fused = nsctrec(fusedCoeffs, dfilt, pfilt);
end