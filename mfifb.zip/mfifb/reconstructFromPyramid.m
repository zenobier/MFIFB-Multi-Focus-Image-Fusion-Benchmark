function img = reconstructFromPyramid(pyr)
    % 重构图像从拉普拉斯金字塔
    numLevels = length(pyr);
    img = pyr{numLevels};
    for level = numLevels-1:-1:1
        expanded = impyramid(img, 'expand');
        expanded = imresize(expanded, size(pyr{level}));
        img = pyr{level} + expanded;
    end
end